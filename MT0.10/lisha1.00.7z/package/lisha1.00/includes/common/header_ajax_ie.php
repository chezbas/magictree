<?php
	header('Content-type: application/xhtml+xml; charset=utf-8');
?>