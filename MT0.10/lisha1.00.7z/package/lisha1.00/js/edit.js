/**==================================================================
 * edit_cell : Recover cells value to update
 * @evt				: catch event
 * @line			: line of cell
 * @column			: Column of cell
 * @lisha_id		: internal lisha identifier
 * @column_format	: format of column eg: __CHECKBOX__
 * @ajax_return 	: return ajax if any
 ====================================================================*/
function edit_cell(evt,line,column,lisha_id, column_format, ajax_return)
{
	var div_adresse = 'div_td_l'+line+'_c'+column+'_'+lisha_id;

	if(eval('varlisha_'+lisha_id+'.CurrentCellUpdate') == "") // Not already cell updating ??
	{
		if(typeof(ajax_return) == 'undefined')
		{
			if(column_format == __CHECKBOX__ )
			{
				// Display the wait div
				lisha_display_wait(lisha_id);
			}
			
			var array_primary_key= JSON.stringify(eval('lisha.'+lisha_id+'.lines.L'+line+'.key'));
			//==================================================================
			// Setup Ajax configuration
			//==================================================================
			var conf = new Array();	
	
			conf['page'] = eval('lisha.'+lisha_id+'.dir_obj')+'/ajax/ajax_page.php';
			conf['delai_tentative'] = 15000;
			conf['max_tentative'] = 4;
			conf['type_retour'] = false;		// ReponseText
			conf['param'] = 'lisha_id='+lisha_id+'&ssid='+eval('lisha.'+lisha_id+'.ssid')+'&action=22&arraykey='+array_primary_key+'&column='+column;
			conf['fonction_a_executer_reponse'] = 'edit_cell';
			conf['param_fonction_a_executer_reponse'] = "'"+evt+"',"+line+",'"+column+"','"+lisha_id+"','"+column_format+"'";
			
			ajax_call(conf);
			//==================================================================
		}
		else
		{	
			// Ajax return
			var retour = JSON.parse(ajax_return);
	
			if(column_format != __CHECKBOX__)
			{
				// Record current cell updating reference
				eval('varlisha_'+lisha_id+'.CurrentCellUpdate = "'+div_adresse+'"');
				
				// Keep cell original value in memory
				lis_lib[57].replace(/\$name/g,eval('varlisha_'+lisha_id+'.CurrentCellName'));
				
				eval('varlisha_'+lisha_id+'.CellUpdateOriginValue = "'+document.getElementById(div_adresse).innerHTML.replace(/[\\]/g, '\\\\').replace(/"/g,'\\"')+'"');
	
				// Compel of column
				eval('varlisha_'+lisha_id+'.CurrentCellCompel = "'+retour.COMPEL+'"');
				
				// Name of column
				eval('varlisha_'+lisha_id+'.CurrentCellName = "'+retour.DISPLAY_NAME+'"');
				
				var html = retour.HTML;
	
				if(html != null) // Check if null
				{
					html = html.replace(/"/g,'&quot;');
				}
				else
				{
					html = '';
				}
				
				//==================================================================
				// Compute input box size
				// minimu size length = 8
				//==================================================================
				if(html.length < 8)
				{
					var input_size = 8;
				}
				else
				{
					var input_size = html.length;
				}
				//==================================================================
	
				document.getElementById(div_adresse).innerHTML = '<input type="text" onclick="lisha_StopEventHandler(event);" size="'+input_size+'" onkeydown="return input_key_manager(event,\''+lisha_id+'\',\''+line+'\',\''+column+'\')" id=\''+div_adresse+'_input\' value="'+html+'"><div id=\''+div_adresse+'_input_message\' style="display:none; color:red; background-color:white; border-radius: 5px;"></div>';
			}
			else
			{
				// checkbox case

				// Record vertical lift position
				eval('varlisha_'+lisha_id+'.scrollTop = '+document.getElementById('liste_'+lisha_id).scrollTop);

				// Refresh page
				lisha_page_change_ajax(lisha_id,eval('lisha.'+lisha_id+'.active_page'));

				// Display the wait div
				lisha_display_wait(lisha_id);
			}
			
			// Force focus
			if(document.getElementById(div_adresse+'_input') != undefined)
			{
				document.getElementById(div_adresse+'_input').focus();
			}
		}
	}
	else
	{
		if(eval('varlisha_'+lisha_id+'.CurrentCellUpdate') != div_adresse )
		{
			// Click another cell, then cancel this one

			// Restore original innerHTML content
			var divadr = eval('varlisha_'+lisha_id+'.CurrentCellUpdate');
			document.getElementById(divadr).innerHTML = eval('varlisha_'+lisha_id+'.CellUpdateOriginValue');
			
			// Clear current cell value
			eval('varlisha_'+lisha_id+'.CurrentCellUpdate = ""');

		}
	}
}
/**==================================================================*/


/**==================================================================
 * input_key_manager : Manage keypress on input cell
 * @evt : catch browser event
 ====================================================================*/
function input_key_manager(evt,lisha_id,line,column)
{
	var charCode = (evt.which) ? evt.which : event.keyCode;

	var div_root_updating = 'div_td_l'+line+'_c'+column+'_'+lisha_id;
	
	if(charCode == 27) // Escape... Cancel action
	{
		// Restore original innerHTML content
		var divadr = eval('varlisha_'+lisha_id+'.CurrentCellUpdate');
		document.getElementById(divadr).innerHTML = eval('varlisha_'+lisha_id+'.CellUpdateOriginValue');
		
		// Clear tempo current cell value
		eval('varlisha_'+lisha_id+'.CurrentCellUpdate = ""');
	}

	if(charCode == 13) // Enter
	{
		//alert('return');
		
		//encodeURIComponent()
		var input_updating = document.getElementById(div_root_updating+'_input').value;

		// Check Compel
		if(eval('varlisha_'+lisha_id+'.CurrentCellCompel') == __REQUIRED__ && input_updating == "")
		{
			
			var message = lis_lib[57].replace(/\$name/g,eval('varlisha_'+lisha_id+'.CurrentCellName')); // Replace $name;
			document.getElementById(div_root_updating+'_input_message').innerHTML = message;
			document.getElementById(div_root_updating+'_input_message').style.display = 'block';
		}
		else
		{
			// Compel passed... go on
			
			// Hide error message div
			document.getElementById(div_root_updating+'_input_message').style.display = 'none';

			
			var array_primary_key= JSON.stringify(eval('lisha.'+lisha_id+'.lines.L'+line+'.key'));
			//==================================================================
			// Setup Ajax configuration
			//==================================================================
			var conf = new Array();	
	
			conf['page'] = eval('lisha.'+lisha_id+'.dir_obj')+'/ajax/ajax_page.php';
			conf['delai_tentative'] = 15000;
			conf['max_tentative'] = 4;
			conf['type_retour'] = false;		// ReponseText
			conf['param'] = 'lisha_id='+lisha_id+'&ssid='+eval('lisha.'+lisha_id+'.ssid')+'&action=23&arraykey='+array_primary_key+'&column='+column+'&val='+encodeURIComponent(input_updating);
			conf['fonction_a_executer_reponse'] = 'ok_edit_cell';
			conf['param_fonction_a_executer_reponse'] = "'"+evt+"',"+line+",'"+lisha_id+"'";
			
			ajax_call(conf);
			//==================================================================
		}
	}
}
/**==================================================================*/


/**==================================================================
 * ok_edit_cell : Cell update done successfully
 * @evt				: catch browser event
 * @line			: Number of line clicked on screen
 * @lisha_id		: internal lisha identifier
 * @ajax_return		: ajax return of standard object
 ====================================================================*/
function ok_edit_cell(evt,line,lisha_id,ajax_return)
{	
	// Clear tempo current cell value
	eval('varlisha_'+lisha_id+'.CurrentCellUpdate = ""');
	
	// Record vertical lift position
	eval('varlisha_'+lisha_id+'.scrollTop = '+document.getElementById('liste_'+lisha_id).scrollTop);
	
	// Refresh page
	lisha_page_change_ajax(lisha_id,eval('lisha.'+lisha_id+'.active_page'));
		
	lisha_execute_event(__ON_UPDATE__,__AFTER__,lisha_id);
}
/**==================================================================*/


/**==================================================================
 * edit_lines : update a full line
 * @evt			: catch event
 * @line		: line of cell
 * @lisha_id	: internal lisha identifier
 * @ajax_return : return ajax if any
 ====================================================================*/
function edit_lines(evt,line,lisha_id,ajax_return)
{
	if(typeof(ajax_return) == 'undefined')
	{
		if(count_selected_lines(lisha_id) > 0 || line != null)
		{
			//var jsoncolorindex = eval('lisha.'+lisha_id+'.lines.L'+line+'.colorkey');
			lisha_StopEventHandler(evt);
			if(line != null && eval('lisha.'+lisha_id+'.return_mode') != __SIMPLE__ && !document.getElementById('chk_l'+line+'_c0_'+lisha_id).checked)
			{
				// Edit button was clicked on the line
				lisha_checkbox(line,evt,null,lisha_id);	
			}
			else
			{
				if(line != null)
				{
					//document.getElementById('l'+line+'_'+id).className = 'line_selected_color_'+jsoncolorindex+'_'+id;

					document.getElementById('chk_l'+line+'_c0_'+lisha_id).checked = true;
					eval('lisha.'+lisha_id+'.selected_line.L'+line+' = lisha.'+lisha_id+'.lines.L'+line+';');
					eval('lisha.'+lisha_id+'.selected_line.L'+line+'.selected = true;');
				}
			}
			
			// Display the wait div
			lisha_display_wait(lisha_id);

			/**==================================================================
			 * Ajax init
			 ====================================================================*/
			var conf = new Array();	

			conf['page'] = eval('lisha.'+lisha_id+'.dir_obj')+'/ajax/ajax_page.php';
			conf['delai_tentative'] = 15000;
			conf['max_tentative'] = 4;
			conf['type_retour'] = false;		// ReponseText
			conf['param'] = 'lisha_id='+lisha_id+'&ssid='+eval('lisha.'+lisha_id+'.ssid')+'&action=13&lines='+encodeURIComponent(get_selected_lines(lisha_id));
			conf['fonction_a_executer_reponse'] = 'edit_lines';
			conf['param_fonction_a_executer_reponse'] = "'"+evt+"',"+line+",'"+lisha_id+"'";
			
			ajax_call(conf);
			/**==================================================================*/
		}
		else
		{
			msgbox(lisha_id,lis_lib[53],lis_lib[52]);
		}
	}
	else
	{
		try 
		{
			// Get the ajax return in json format
			var json = get_json(ajax_return);

			// Update the json
			eval(decodeURIComponent(json.lisha.json));
			
			// Set the content of the lisha
			lisha_set_content(lisha_id,decodeURIComponent(json.lisha.content));
			
			// Disable delete button when try to update rows
			eval('lisha.'+lisha_id+'.selected_line = "";');

			// Set the content of the toolbar
			lisha_set_innerHTML('lisha_toolbar_'+lisha_id,decodeURIComponent(json.lisha.toolbar));
			
			// Set the focus to the default input
			if(eval('lisha.'+lisha_id+'.default_input_focus') != false)
			{
				document.getElementById('th_input_'+eval('lisha.'+lisha_id+'.default_input_focus')+'__'+lisha_id).focus();
			}

			// Hide the wait div
			lisha_display_wait(lisha_id);
			
			document.getElementById('lisha_table_mask_'+lisha_id).style.display = 'block';
		} 
		catch(e)
		{
			lisha_display_error(lisha_id,e,ajax_return);
		}
	}
}
/**==================================================================*/


function lisha_cancel_edit(lisha_id,ajax_return)
{
	if(typeof(ajax_return) == 'undefined')
	{
		// Display the wait div
		lisha_display_wait(lisha_id);
		
		/**==================================================================
		 * Ajax init
		 ====================================================================*/	
		var conf = new Array();	
		
		conf['page'] = eval('lisha.'+lisha_id+'.dir_obj')+'/ajax/ajax_page.php';
		conf['delai_tentative'] = 3000;
		conf['max_tentative'] = 4;
		conf['type_retour'] = false;		// ReponseText
		conf['param'] = 'lisha_id='+lisha_id+'&ssid='+eval('lisha.'+lisha_id+'.ssid')+'&action=20';
		conf['fonction_a_executer_reponse'] = 'lisha_cancel_edit';
		conf['param_fonction_a_executer_reponse'] = "'"+lisha_id+"'";

		ajax_call(conf);
		/**==================================================================*/
	}
	else
	{
		try
		{
			// Get the ajax return in json format
			var json = get_json(ajax_return);

			// Update the json
			eval(decodeURIComponent(json.lisha.json));
			
			// Set the content of the lisha
			lisha_set_content(lisha_id,decodeURIComponent(json.lisha.content));
			
			// Set the content of the toolbar
			lisha_set_innerHTML('lisha_toolbar_'+lisha_id,decodeURIComponent(json.lisha.toolbar));
			
			// Hide the wait div
			lisha_display_wait(lisha_id);
		} 
		catch (e)
		{
			
		}
	}
}
function delete_lines(lisha_id,confirm,ajax_return)
{
	if(typeof(ajax_return) == 'undefined')
	{
		if(count_selected_lines(lisha_id) > 0)
		{
			if(!confirm)
			{
				lisha_cover_with_filter(lisha_id);
				var prompt_btn = new Array([lis_lib[31],lis_lib[32]],["delete_lines('"+lisha_id+"',true)","lisha_cover_with_filter('"+lisha_id+"');"]);
				
				document.getElementById('lis_msgbox_conteneur_'+lisha_id).style.display = '';
				lisha_generer_msgbox(lisha_id,lis_lib[54],lis_lib[55].replace('$x',count_selected_lines(lisha_id)),'info','msg',prompt_btn);
			}
			else
			{
				lisha_execute_event(__ON_DELETE__,__BEFORE__,lisha_id);
				
				// Hide the promptbox
				lisha_cover_with_filter(lisha_id);
				
				// Display the wait div
				lisha_display_wait(lisha_id);
				
				/**==================================================================
				 * Ajax init
				 ====================================================================*/	
				var conf = new Array();	
	
				conf['page'] = eval('lisha.'+lisha_id+'.dir_obj')+'/ajax/ajax_page.php';
				conf['delai_tentative'] = 15000;
				conf['max_tentative'] = 4;
				conf['type_retour'] = false;		// ReponseText
				conf['param'] = 'lisha_id='+lisha_id+'&ssid='+eval('lisha.'+lisha_id+'.ssid')+'&action=15&lines='+encodeURIComponent(get_selected_lines(lisha_id));
				conf['fonction_a_executer_reponse'] = 'delete_lines';
				conf['param_fonction_a_executer_reponse'] = "'"+lisha_id+"',true";
		
				ajax_call(conf);
				/**==================================================================*/
			}
		}
		else
		{
			msgbox(lisha_id,lis_lib[51],lis_lib[52]);
		}
	}
	else
	{
		try 
		{
			// Get the ajax return in json format
			var json = get_json(ajax_return);
			
			// Update the json
			eval(decodeURIComponent(json.lisha.json));
			
			// Set the content of the lisha
			lisha_set_content(lisha_id,decodeURIComponent(json.lisha.content));
			
			lisha_set_innerHTML('lisha_toolbar_'+lisha_id,decodeURIComponent(json.lisha.toolbar));

			// Hide the cover div
			var theme = eval('lisha.'+lisha_id+'.theme');
			document.getElementById('lis__'+theme+'__hide_container_'+lisha_id+'__').style.display = 'none';
			
			// Erase the content of the wait div
			lisha_set_innerHTML('lis__'+theme+'__wait_'+lisha_id+'__','');
			
			// Erase the content of the msgbox div
			lisha_set_innerHTML('lis_msgbox_conteneur_'+lisha_id,'');
			
			lisha_execute_event(__ON_DELETE__,__AFTER__,lisha_id);
		} 	
		catch(e)
		{
			lisha_display_error(lisha_id,e);
			alert(ajax_return);
		}
	}
}

/**==================================================================
 * Add line action
 * @param		: lisha_id Id of the lisha
 * @ajax_return	: use with ajax return
====================================================================*/
function add_line(lisha_id,ajax_return)
{
	if(typeof(ajax_return) == 'undefined')
	{
		lisha_execute_event(__ON_ADD__,__BEFORE__,lisha_id);
		
		// Display the wait div
		lisha_display_wait(lisha_id);
		
		//==================================================================
		// Build json columns values only those are checked
		//==================================================================
		var val = new Object();
		for(var iterable_element in eval('lisha.'+lisha_id+'.columns')) 
		{
			var i = eval('lisha.'+lisha_id+'.columns.'+iterable_element+'.id');
			if(i != undefined)
			{
				eval('val.'+iterable_element+' = new Object();');
				eval('val.'+iterable_element+'.value = \''+protect_json(document.getElementById('th_input_'+i+'__'+lisha_id).value)+'\';');
				eval('val.'+iterable_element+'.id = '+i+';'); // raw column compteur 1....2....3 and so on
				eval('val.'+iterable_element+'.idorigin = '+eval('lisha.'+lisha_id+'.columns.c'+i+'.idorigin')+';'); // Original id position of column
			}
		}
		//==================================================================
		//alert(JSON.stringify(val));
		
		//==================================================================
		// Setup Ajax configuration
		//==================================================================
		var conf = new Array();	
		conf['page'] = eval('lisha.'+lisha_id+'.dir_obj')+'/ajax/ajax_page.php';
		conf['delai_tentative'] = 15000;
		conf['max_tentative'] = 4;
		conf['type_retour'] = false;		// ReponseText
		conf['param'] = 'lisha_id='+lisha_id+'&ssid='+eval('lisha.'+lisha_id+'.ssid')+'&action=16&val_json='+encodeURIComponent(JSON.stringify(val));
		conf['fonction_a_executer_reponse'] = 'add_line';
		conf['param_fonction_a_executer_reponse'] = "'"+lisha_id+"'";

		ajax_call(conf);
		//==================================================================
	}
	else
	{
		try 
		{
			// Hide the wait div
			lisha_display_wait(lisha_id);
			
			// Get the ajax return in json format
			var json = get_json(ajax_return);

			if(json.lisha.error == 'false')
			{
				// An error has occured
				eval('var test = '+decodeURIComponent(json.lisha.error_col));
				for(var iterable_element in test) 
				{
					if(eval('test.'+iterable_element+'.status') == __FORBIDDEN__)
					{
						// forbidden
						document.getElementById('th_input_'+eval('test.'+iterable_element+'.id')+'__'+lisha_id).value = '';
						document.getElementById('th_input_'+eval('test.'+iterable_element+'.id')+'__'+lisha_id).disabled = 'true';
					}
					else
					{
						// Required
						document.getElementById('th_input_'+eval('test.'+iterable_element+'.id')+'__'+lisha_id).style.backgroundColor = '#FFD4D4';
					}
				}
				
				lisha_cover_with_filter(lisha_id);
				prompt_btn = new Array([lis_lib[31]],["lisha_cover_with_filter('"+lisha_id+"');"]);
				
				document.getElementById('lis_msgbox_conteneur_'+lisha_id).style.display = '';
				lisha_generer_msgbox(lisha_id,lis_lib[56],decodeURIComponent(json.lisha.error_str),'erreur','msg',prompt_btn);
			}
			else
			{
				// No error
				
				// Update the json
				eval(decodeURIComponent(json.lisha.json));
	
				// Set the content of the lisha
				lisha_set_content(lisha_id,decodeURIComponent(json.lisha.content));

				// Set the content of the toolbar
				lisha_set_innerHTML('lisha_toolbar_'+lisha_id,decodeURIComponent(json.lisha.toolbar));
				
			}
			
			document.getElementById('wait_input_'+lisha_id).style.display = 'none';
			
			lisha_execute_event(__ON_ADD__,__AFTER__,lisha_id);
			
		} 
		catch(e) 
		{
			alert(ajax_return);
			lisha_display_error(lisha_id,e);
		}
	}
}
/**==================================================================*/


/**==================================================================
 * Add line action
 * @param		: lisha_id Id of the lisha
 * @ajax_return	: use with ajax return
====================================================================*/
function save_lines(lisha_id,ajax_return)
{
	if(typeof(ajax_return) == 'undefined')
	{
		// Display the wait div
		lisha_display_wait(lisha_id);
		
		lisha_execute_event(__ON_UPDATE__,__BEFORE__,lisha_id);
		
		//==================================================================
		// Build json columns values only those are checked
		//==================================================================
		var val = new Object();
		for(var iterable_element in eval('lisha.'+lisha_id+'.columns')) 
		{
			var i = eval('lisha.'+lisha_id+'.columns.'+iterable_element+'.id');
			if(i != undefined)
			{
				if(document.getElementById('chk_edit_c'+i+'_'+lisha_id) && document.getElementById('chk_edit_c'+i+'_'+lisha_id).checked == true)
				{
					eval('val.'+iterable_element+' = new Object();');
					eval('val.'+iterable_element+'.value = \''+protect_json(document.getElementById('th_input_'+i+'__'+lisha_id).value)+'\';');
					eval('val.'+iterable_element+'.id = '+i+';');
				}
			}
		}
		//==================================================================

		//==================================================================
		// Setup Ajax configuration
		//==================================================================
		var conf = new Array();

		conf['page'] = eval('lisha.'+lisha_id+'.dir_obj')+'/ajax/ajax_page.php';
		conf['delai_tentative'] = 15000;
		conf['max_tentative'] = 4;
		conf['type_retour'] = false;		// ReponseText
		conf['param'] = 'lisha_id='+lisha_id+'&ssid='+eval('lisha.'+lisha_id+'.ssid')+'&action=14&val_json='+encodeURIComponent(JSON.stringify(val));
		conf['fonction_a_executer_reponse'] = 'save_lines';
		conf['param_fonction_a_executer_reponse'] = "'"+lisha_id+"'";

		ajax_call(conf);
		//==================================================================
	}
	else
	{
		try 
		{
			// Get the ajax return in json format
			var json = get_json(ajax_return);
			
			// Update the json
			eval(decodeURIComponent(json.lisha.json));

			// Set the content of the lisha
			lisha_set_content(lisha_id,decodeURIComponent(json.lisha.content));
			
			lisha_set_innerHTML('lisha_toolbar_'+lisha_id,decodeURIComponent(json.lisha.toolbar));
			
			document.getElementById('wait_input_'+lisha_id).style.display = 'none';
			
			lisha_execute_event(__ON_UPDATE__,__AFTER__,lisha_id);
		} 
		catch(e)
		{
			alert(ajax_return);
			lisha_display_error(lisha_id,e);
		}
		
		// Hide the wait div
		lisha_display_wait(lisha_id);
	}
}
/**==================================================================*/


function protect_json(p_value)
{
	p_value = p_value.replace(new RegExp('\\\\','g'),"\\\\");
	p_value = p_value.replace(new RegExp("'",'g'),"\\'");
	return p_value;
}